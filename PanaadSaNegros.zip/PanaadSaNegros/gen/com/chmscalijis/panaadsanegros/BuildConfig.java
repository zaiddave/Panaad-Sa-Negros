/** Automatically generated file. DO NOT MODIFY */
package com.chmscalijis.panaadsanegros;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}