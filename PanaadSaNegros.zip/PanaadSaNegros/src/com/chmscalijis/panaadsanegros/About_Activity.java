package com.chmscalijis.panaadsanegros;

import java.util.List;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chmscalijis.panaadsanegros.message.BackgroundTaskMessage;
import com.chmscalijis.panaadsanegros.message.MessageModel;
import com.chmscalijis.panaadsanegros.message.Message_DatabaseHelper;



public class About_Activity extends ActionBarActivity{
	
	private Message_DatabaseHelper db;
	Button toggle,history,logo,founders,committees,gethere,message,developers;
	LinearLayout history1,logo1,founders1,committees1,gethere1,message1,developers1;
	Animation slide_down, slide_up;
	ImageButton back;	
	ImageView founderslogo1,fb,twitter,rss;
	WebView una,kaduwa,logoText,foundersText,committeesText,gethereText, msgCntnt;
	String txt6 =  "<html><body>"
			+ "<p align=\"left\">"
			+"<br><br><b>From Bacolod-Silay Airport</b>"
			+"<br><br>Ride via taxi going to Panaad Park and Stadium"
			+"<br><br><i>Available Routes:</i>"
			+"<br>via Bacolod Airport Access Road and Carlos Hilado Highway/Circumferencial Road"
			+"<br>Estimated travel time: 34 to 37 minutes"
			+"<br>Estimated travel distance: 22.0 km"
			+"<br>View via Google Map: <a href='https://goo.gl/maps/QBGSndS1k6p'>Click Here...</a>"
			
			+"<br><br><br><br><b>From BREDCO Seaport (Bacolod)</b>"
			+"<br><br>Ride via taxi going to Panaad Park and Stadium"
			+"<br><br><i>Available Routes:</i>"
			+"<br>via Alijis Road"
			+"<br>via Lacson Street and Alijis Road"
			+"<br>via P. Hernaez Street Extension"
			+"<br>Estimated travel time: 23 to 26 minutes"
			+"<br>Estimated travel distance: 10.3 to 10.9 km"
			+"<br>View via Google Map: <a href='https://goo.gl/maps/afxdyJWkpK82'>Click Here...</a>"
			
			+"<br><br><br><br><b>From Bacolod Northbound Ceres Bus Terminal</b>"
			+"<br><br>Ride via taxi going to Panaad Park and Stadium"
			+"<br><br><i>Available Routes:</i>"
			+"<br>via Lacson Street"
			+"<br>via Carlos Hilado Highway/Circumferencial Road"
			+"<br>via Lacson Street Extension and Carlos Hilado Highway/Circumferencial Road"
			+"<br>Estimated travel time: 27 to 30 minutes"
			+"<br>Estimated travel distance: 12.1 to 15.8 km"
			+"<br>View via Google Map: <a href='https://goo.gl/maps/suMehMVsfJC2'>Click Here...</a>"
			
			+"<br><br><br><br><b>From Bacolod Ceres South Bus Terminal</b>"
			+"<br><br>Ride via taxi going to Panaad Park and Stadium"
			+"<br><br><i>Available Routes:</i>"
			+"<br>via P. Hernaez Street Extension"
			+"<br>via P. Hernaez Street Extension and Carlos Hilado Highway/Circumferential Road"
			+"<br>via Carlos Hilado Highway/Circumferential Road"
			+"<br>Estimated travel time: 14 to 15 minutes"
			+"<br>Estimated travel distance: 6.2 to 6.9 km"
			+"<br>View via Google Map: <a href='https://goo.gl/maps/egQzotqLVQP2'>Click Here...</a>"
			
			+"<br><br><br><br><b>From Dumaguete Airport, Sibulan, Negros Oriental</b>"
			+"<br><br>Ride via taxi or van going to Panaad Park and Stadium"
			+"<br><br><i>Available Routes:</i>"
			+"<br>via Kabankalan-Mabinay-Bais Road and Araneta Avenue/National Highway/National Road/Negros South Road"
			+"<br>Estimated travel time: 4 hours 39 minutes"
			+"<br>Estimated travel distance: 212 km"
			+"<br>View via Google Map: <a href='https://goo.gl/maps/BwonGQGnp6N2'>Click Here...</a>"
			
			+"<br><br><br><br><b>You may contact Negros Occidental Tourism Division (Festival Secretariat) for further guidance and assistance on how to go to Panaad sa Negros Festival activity venues and available travel packages connected to the festival.</b>"
			+"<br><br><i>Phone:</i> <a href='tel:0347098875'>(034) 709-8775</a> / <a href='tel:0344762018'>476-2018</a>"
			+"<br><i>Telefax:</i> <a href='tel:0344332515'>(034) 433-2515</a>"
			+"<br><i>Email Address:</i> <a href='mailto:secretariat@panaadsanegros.com'>secretariat@panaadsanegros.com</a>"
			+"<br><i>Facebook Page:</i>  <a href='https://www.facebook.com/negrosoccidentaltourismcenter/'>https://www.facebook.com/negrosoccidentaltourismcenter/</a>"
						
			+"</p>"
			+"</body></html>";
	String txt5 =  "<html><body>"
			+ "<p align=\"justify\">"
			+"<br><br><b>Executive Committee</b>"
			+"<br><br><br><br>Chairman: GOV. ALFREDO G. MARA&NtildeON, JR."
			+"<br><br><br><br>Members:"
			+"<br><br>SP Committee on Tourism Chairman - SPM PATRICK LEONARD S. LACSON"
			+"<br><br>Provincial Consultant on Administration and Finance - MR. ROY I. BALICAS"
			+"<br><br>Provincial Consultant on Investment Promotions, Trade and Export Development, and Inter-Agency Coordination - MR. RAFAEL L. COSCOLLUELA"
			+"<br><br>Representative of Partner NGO: Pag-ugyon Negros Foundation, Inc."
			+"<br><br>Executive Director/Action Officer: DR. MA. LINA P. SANOGAL, PPDC"
			+"<br><br><br><br><b>Working Committees</b>"
			+"<br><br>Secretariat/Reception: Governor's Office - Negros Occidental Tourism Division (Ms. Cristine C. Mansinares)"
			+"<br><br><br><br><b>Finance and Procurement:</b>"
			+"<br><br>Provincial Budget Office (Mr. Jose Percival P. Salado, Jr.)"
			+"<br><br>Provincial Treasurer's Office (Ms. Nilda V. Generoso)"
			+"<br><br>Provincial Accounting Office (Ms. Merly P. Fortu)"
			+"<br><br>Governor's Office - Internal Audit Division (Mr. Carolina G. Isuga)"
			+"<br><br><br><br><b>Physical Arrangement, Electrical, and Ground Maintenance:</b>"
			+"<br><br>Provincial Administrator's Office - Special Programs and Concerns "
			+"<br><br>Division (SPCD - Mr. Ian A. de Ramos)"
			+"<br><br>Provincial General Services Office (Ms. Lucille C. Pines)"
			+"<br><br>Provincial Engineer's Office (Engr. Ernie F. Mapa)"
			+"<br><br><br><br><b>Publicity, Marketing, and Documentation:</b>"
			+"<br><br>Governor's Office (NOIPC-PIS - Ms. Karen R. Dinsay)"
			+"<br><br>Legal Services: Provincial Legal Office (Atty. Mary Ann M. Lamis)"
			+"<br><br>Clinic/Medical Services: PHO - Medical Clinic (Dr. Ernell J. Tumimbang)"
			+"<br><br>Security, Law Enforcement, Emergency Response, Traffic and Crowd Management:Panaad Security Office, APSA, NRF, PRC, BFP, PCG, 303Bde PA, BCPO - BAC UP 7, NOPPO (P/Sr. Supt. Wiiliam Senoron with Mr. Orlando Jundos)"
			+"<br><br><br><br><br><b>Events Management and Related Services</b>"
			+"<br><br>Destination Pavilion Contest, Motorcade, and Exhibits:"
			+"<br><br>Negros Occidental Tourism Division (Ms. Cristine C. Mansinares)"
			+"<br><br>Trade Fair/Products Display: Negros Occidental TLDC (Mr. Ricardo D. Calse&ntildea)"
			+"<br><br>Agricultural Fair: Office of the Provincial Agriculture (Engr. Igmedio J. Tabianan)"
			+"<br><br>Livestock and Daisy Fair: Office of the Provincial Veterinary (Dr. Renante J. Decena)"
			+"<br><br>Environment Activities: Provincial Environment Management Office (Atty. Wilfred Ramon M. Pe&ntildealosa)"
			+"<br><br>Lin-ay sang Negros Pageant/Opening and Closing Program: Mr. Ian de Ramos (SPCD)"
			+"<br><br>Festival Dances Competition: Mr. Rodolfo M. Reveche"
			+"<br><br>Folk Dance Competition: Ms. Grace Lipa (PPDO) and Msgr. Guillermo Ma. A. Gaston"
			+"<br><br>Latin Dance Competition: Ms. Jesstha Chris T. Alcala (Provincial Admin Office)"
			+"<br><br>Rondalla and Binalaybay Competition: Ms. Evijane T. Vi&ntildeas (PPDO) and Msgr. Guillermo Ma. A. Gaston"
			+"<br><br>LGU Chorale Competition (Koro sang mga Empleyado):Mr. Serry Repique and Mr. Romeo Gamilla"
			+"<br><br>Drum and Bugle Competition: Ms. Rema Annie E. Decatoria (SPCD - Public Affairs Section)"
			+"<br><br>Sports Events: Mr. Angel M. Verdeflor with SPCD - Sports Development Section"
			+"<br><br>Technical Skills Olympics: TESDA Provincial Office (Ms.Rosario R. Heria)"
			+"<br><br>Provincial Employees Day: PHRMO (Atty. Anabelle S. Palic) with PACE and CAPGEM"
			+"<br><br>Lin-ay and Special Events Ushering: Dr. Ann Murillo/Ms. Mina Pellejo with Selected Capitol Employees"
			+"<br><br>Corporate/Special Events: Ms. Karen R. Dinsay with Corporate Sponsors"
			+"<br><br>Official Tabulation: Mr. Merly P. Fortu with PAO and ICT Division Staff"
			+"</p>"
			+"</body></html>";
	String txt4 =  "<html><body>"
			+"<p align=\"justify\">"
			+"<br><br>Hon. Rafael L. Coscolluela, Governor, 1992-2001"
			+"<br><br>Hon. Romeo J. Gamboa, Jr., Vice Governor, 1992-2001"
			+"<br><br>Hon. Michael K. Suarez, Board Member, Tourism Committee"
			+"<br><br>Hon. Monico O. Puentevella, President, NOCSF"
			+"<br><br>Hon. Regina S. Ledesma, Member, NOCSF Board"
			+"<br><br>Mrs. Erlinda Jara, Member, NOCSF Board"
			+"<br><br>Mr. Eusebio W. Po, Member, NOCSF Board"
			+"<br><br>Mr. Andres Valencia, Member, NOCSF Board"
			+"<br><br>Mr. Joaquin Teves, Member, NOCSF Board"
			+"<br><br>Mrs. Angelina Echaus, Member, NOCSF Board"
			+"<br><br>Hon. Eduardo Ledesma, Member, NOCSF Board"
			+"<br><br>Mrs. Amalia Unson, Member, NOCSF Board"
			+"<br><br>Mr. Wilmar Drilon, Member, NOCSF Board"
			+"<br><br>Mr. Bob Chugani, Member, NOCSF Board"
			+"<br><br>Atty. Roberto C. Leong, Member, NOCSF Board"
			+"<br><br>Bro. Rolando R. Dizon, Member, NOCSF Board"
			+"<br><br>Msgr. John B. Liu, Member, NOCSF Board"
			+"<br><br>Arch. Silverio Ureta, UAP-Negros Occ. Chapter"
			+"<br><br>Arch. Noli Puentevella, UAP-Negros Occ. Chapter"
			+"<br><br>Arch. Rica Suarez, UAP-Negros Occ. Chapter"
			+"<br><br>Msgr. Guillermo G. Gaston"
			+"<br><br>Ms. Girlie Y. Belzunce"
			+"<br><br>Ms. Cecile Asico"
			+"<br><br>Ms. Donna Porter"
			+"<br><br>Ms. Charito Motus"
			+"<br><br>Mr. Rene Hinojales"
			+"<br><br>(NOCSF - Negros Occidental Sports and Cultural Foundation)"
			+"</p>"
			+"</body></html>";
	String txt3 =  "<html><body>"
			+ "<p align=\"justify\">"
			+"&nbsp;&nbsp;&nbsp;&nbsp;The rainbow signifies firm, solid and absolute promise of God as the source of everything, as the rising sun symbolizes the brightness of hope for the people of Negros Occidental, represented by the boot-shaped cloud."
			+"</p>"
			+"</body></html>";
	String txt2 = "<html><body>"
			+ "<p align=\"justify\">"
			+"<br>&nbsp;&nbsp;&nbsp;&nbsp;Capture the essence of Negros Occidental in the annual celebration of Panaad sa Negros Festival every March or April in Bacolod City."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Dubbed the \"Festival of Festivals\", Panaad (Hiligaynon for a vow and its fulfilment) Festival is a colorful and jubilant presentation of individual festivals of the 13 cities and 19 municipalities of Negros Occidental. It presents Bacolod City's famous Masskara, La Carlota's rhythmic Pasalamat, San Carlos City's multi-awarded Pintaflores, Kabankalan City's Sinulog, Bago City's Babaylan, Escalante City's Manlambus, Sagay City's Sinigayan, Cadiz City's Dinagsa, Mambukal's Mudpack, San Enrique's Bulang-Bulang, La Castellana's Bailes de Luces, Salvador Benedicto's Kali-Kalihan, Isabela's Tigkalalag and many more."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;It brings together the 32 LGUs in an array of theme pavilions that showcase their history, arts and culture, tourism, commerce, trade and industry, in the 25-hectare eucalyptus trees-lined Panaad Park and Stadium (Sports Complex)."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Panaad Festival is also a time for renewing bonds or initiating friendships. The festival attracts most of the 2.8 million strong Negrenses, their balikbayan relatives and friends, who get a glimpse of the best offerings of the towns and cities in a tour of the uniquely designed pavilions, as well as in cultural presentations for beauty, talent, skills, and in sports."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Free shows or concerts by popular Manila-based artists add fun and excitement to the festivals. The fun continues in the food and drinks alley that offers the famous chicken inasal, grilled fish and seafood, including various shellfish, oysters, and scallops. Local bands perform nightly till way past midnight in the food and drinks alley. Panaad Festival also features the gains the province has achieved in its diversification efforts and its priority agenda, particularly in Food Security and Agricultural Productivity."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;It is seriously developing its rice and corn industries and positioning livestock as its second major industry, next to sugar. It is also targetting to be a major player in the world market for organic agriculture, having been declared the Philippines' organic agriculture leader by the Department of Agriculture."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;With the Negrenses' pioneering spirit, Negros is no longer just sugar; it is also cut-flowers and ornamentals, high value fruits and organically-grown vegetables, prawns and seafood, champion fighting cocks, exquisite handcrafted gift items and house ware, world-class furniture and garments, bio-fuels and more."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Panaad Festival is a thanksgiving celebration and an exhibition of the best of Negros Occidental"
			+"</p>"
			+"</body></html>";
	String txt1 = "<html><body>"
			+"<p align=\"justify\">"
			+"<br>&nbsp;&nbsp;&nbsp;&nbsp;Panaad sa Negros Festival was conceptualized in 1993 by the Provincial Government and representatives of the private sector to showcase the festivals of each of the then six (6) cities and 26 municipalities of Negros Occidental - their history, cultural heritage, commerce and industry and tourism potential. This was to be a yearly summer event for Negrenses, both here and abroad, to look forward to and come home for."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The first Panaad sa Negros Festival was a three-day affair in 1993 that started April 30, a significant day because on this day in 1901 Negros Occidental became a separate and distinct province from Negros Oriental. The separation and incorporation of both Negros provinces was to take effect on May 1, 1901."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The festival was held at the Provincial Park and Lagoon fronting the Provincial Capitol for the first four years. As the festival grows each year, it became necessary to look for a bigger venue. In 1997, the festival was held at the reclaimed area near where BREDCO Port is located now."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The construction of the Panaad stadium and swimming complex in Mansilingan, Bacolod City for the Palarong Pambansa in 1998 paved the way for the establishment of the Panaad Park as the permanent home of the festival. The park hosts the pavilions of the now 19 municipalities and 13 cities of Negros Occidental, including the highly urbanized provincial capital, Bacolod City."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The football field is the battleground for the determination of the \"Best of the Festival Dances\", and the Drum and Bugle competitions, among other events."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The stadium, which can accommodate around 25,000 spectators in its main grandstand and open bleachers, is the main venue for the cultural presentations, LGU competitions, concerts, and the festival highlight, the search for the \"Lin-ay sang Negros\", the lady who epitomizes the ideal Negrense woman."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;The festival is supported by the Pag-ugyon Negros Foundation, Inc. and various corporate sponsors attracted by its magnitude and the large crowds it generates."
			+"</p>"
			+"</body></html>";
	
	String msg = "<html><body>"
			+"<p align=\"justify\">"
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;We are inviting everyone to come to Panaad sa Negros Festival and see a microcosm of our beautiful province in a tour of the unique themed pavilions of our 13 cities and 19 towns. See the best that each city and town has to offer in terms of products, arts and culture, tourism destinations, trade and investments, among others."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Experience the brand of Negrense hospitality our visitors come back for, year after year."
			+"<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Come and celebrate with us, as we fulfill our vow for Negros Occidental, now more than just sugar and land of sweet surprises!"
			+"</p>"
			+"</body></html>";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	setContentView(R.layout.about_layout);
	
	//webview
	una=(WebView)findViewById(R.id.textView03);
	kaduwa=(WebView)findViewById(R.id.textView04);
	logoText=(WebView)findViewById(R.id.logoText);
	foundersText=(WebView)findViewById(R.id.foundersText);
	committeesText=(WebView)findViewById(R.id.committeesText);
	gethereText=(WebView)findViewById(R.id.gethereText);
	msgCntnt = (WebView)findViewById(R.id.msgCntnt);
	
	
	//webview loadData
	una.loadData(txt1,"text/html", "utf-8");
	kaduwa.loadData(txt2,"text/html", "utf-8");
	logoText.loadData(txt3,"text/html", "utf-8");
	foundersText.loadData(txt4,"text/html", "utf-8");
	committeesText.loadData(txt5,"text/html", "utf-8");
	gethereText.loadData(txt6,"text/html", "utf-8");
	msgCntnt.loadData(msg,"text/html","utf-8");
		
	//imageview
	founderslogo1=(ImageView)findViewById(R.id.founderslogo1);
	fb =(ImageView)findViewById(R.id.fb);
	twitter = (ImageView)findViewById(R.id.twitter);
	rss =(ImageView)findViewById(R.id.rss);
	
	//button	
	toggle = (Button)findViewById(R.id.toggle);
	history =(Button)findViewById(R.id.history);
	logo =(Button)findViewById(R.id.logo);
	founders =(Button)findViewById(R.id.founders);
	committees =(Button)findViewById(R.id.comitte);
	gethere =(Button)findViewById(R.id.gethere);
	message =(Button)findViewById(R.id.message);
	developers = (Button)findViewById(R.id.developers);
	back = (ImageButton)findViewById(R.id.back);
	
	//linearLayout
	history1 = (LinearLayout)findViewById(R.id.history1);
	logo1 = (LinearLayout)findViewById(R.id.logo1);
	founders1 = (LinearLayout)findViewById(R.id.founders1);
	committees1 = (LinearLayout)findViewById(R.id.comitte1);
	gethere1 = (LinearLayout)findViewById(R.id.gethere1);
	message1 = (LinearLayout)findViewById(R.id.message1);
	developers1 = (LinearLayout) findViewById(R.id.developers1);
	
	//set Button Visibility Gone
	fb.setVisibility(Button.GONE);
	twitter.setVisibility(Button.GONE);
	rss.setVisibility(Button.GONE);
	
	//set LinearLayout Visibility Gone
	history1.setVisibility(LinearLayout.GONE);
	logo1.setVisibility(LinearLayout.GONE);
	founders1.setVisibility(LinearLayout.GONE);
	committees1.setVisibility(LinearLayout.GONE);
	gethere1.setVisibility(LinearLayout.GONE);
	message1.setVisibility(LinearLayout.GONE);
	developers1.setVisibility(LinearLayout.GONE);
	
	
		
	
	//animation
	slide_down = AnimationUtils.loadAnimation(getApplicationContext(),
            R.anim.slide_down);
	slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
            R.anim.slide_up);
	
	//magic	
	toggle_play();
	fb_link();
	twitter_link();
	rss_link();
	
	//function	
	history();
	logo();
	founders();
	committees();
	gethere();
	message();
	developers();
	backPress();

	call(gethereText,"");
	
	
	

	
	   
} 
	

	public boolean call(WebView view,String url){
		if(url.startsWith("tel:")){
			Intent intent = new Intent(Intent.ACTION_CALL);
			intent.setData(Uri.parse(url));
			startActivity(intent);
		}
		if(url.startsWith("mailto:")){
			Intent intent = new Intent(getApplicationContext(),Email_Activity.class);	
			startActivity(intent);
		}
		return true;
		
	}
	
	public void backPress(){
		back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onBackPressed();
			}
		});
		
	}
	public void history(){
		history.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
					
			
			if(history.getText().equals("History of Panaad Festival")){
				history.setText("History of Panaad Festival (show less...)");
				history1.startAnimation(slide_down);
				history1.setVisibility(LinearLayout.VISIBLE);
				history.setBackgroundColor(Color.rgb(255,143,60));
				history.setTextColor(Color.rgb(255,255,255));
				//toggle.setVisibility(Button.GONE);
				
				
			}
			else if(history.getText().equals("History of Panaad Festival (show less...)")){
				history.setText("History of Panaad Festival");
				history1.startAnimation(slide_up);
			
				
			     history1.postDelayed(new Runnable() {

			        public void run() {
			          
			            history1.setVisibility(LinearLayout.GONE);
			            history.setBackgroundColor(Color.rgb(255,255,255));
			        	history.setTextColor(Color.rgb(19,18,18));
			        	//toggle.setVisibility(Button.VISIBLE);
			        }
			    }, 1000);
			}
			}
		});
}
	
	public void message(){
		message.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {				
				
				
				
			if(message.getText().equals("Message from the Governor")){
				message.setText("Message from the Governor (show less...)");
				message1.startAnimation(slide_down);
				message1.setVisibility(LinearLayout.VISIBLE);
				message.setBackgroundColor(Color.rgb(255,143,60));
				message.setTextColor(Color.rgb(255,255,255));
				toggle.setVisibility(Button.GONE);
				
				
				
			}
			else if(message.getText().equals("Message from the Governor (show less...)")){
				message.setText("Message from the Governor");
				message1.startAnimation(slide_up);
				
				
			     message1.postDelayed(new Runnable() {

			        public void run() {
			          
			            message1.setVisibility(LinearLayout.GONE);
			            message.setBackgroundColor(Color.rgb(255,255,255));
						message.setTextColor(Color.rgb(19,18,18));
						toggle.setVisibility(Button.VISIBLE);
			        }
			    }, 1000);
			}
			}
		});
}

	
	public void gethere(){
		gethere.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			if(gethere.getText().equals("How to get here")){
				gethere.setText("How to get here (show less...)");
				gethere1.startAnimation(slide_down);
				gethere1.setVisibility(LinearLayout.VISIBLE);
				gethere.setBackgroundColor(Color.rgb(255,143,60));
				gethere.setTextColor(Color.rgb(255,255,255));
				
			}
			else if(gethere.getText().equals("How to get here (show less...)")){
				gethere.setText("How to get here");
				gethere1.startAnimation(slide_up);
				
				
			     gethere1.postDelayed(new Runnable() {

			        public void run() {
			          
			            gethere1.setVisibility(LinearLayout.GONE);
			            gethere.setBackgroundColor(Color.rgb(255,255,255));
						gethere.setTextColor(Color.rgb(19,18,18));
			          
			        }
			    }, 1000);
			}
			}
		});
}
	
	public void committees(){
		committees.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			if(committees.getText().equals("Festival Committees")){
				committees.setText("Festival Committees (show less...)");
				committees1.startAnimation(slide_down);
				committees1.setVisibility(LinearLayout.VISIBLE);
				committees.setBackgroundColor(Color.rgb(255,143,60));
				committees.setTextColor(Color.rgb(255,255,255));
				
			}
			else if(committees.getText().equals("Festival Committees (show less...)")){
				committees.setText("Festival Committees");
				committees1.startAnimation(slide_up);
				
				
				committees1.postDelayed(new Runnable() {

			        public void run() {
			          
			        	committees1.setVisibility(LinearLayout.GONE);
			        	committees.setBackgroundColor(Color.rgb(255,255,255));
						committees.setTextColor(Color.rgb(19,18,18));
			          
			        }
			    }, 1000);
			}
			}
		});
}
	
	public void founders(){
		founders.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			if(founders.getText().equals("Founders of the Festival")){
				founders.setText("Founders of the Festival (show less...)");
				founders1.startAnimation(slide_down);
				founders1.setVisibility(LinearLayout.VISIBLE);
				founders.setBackgroundColor(Color.rgb(255,143,60));
				founders.setTextColor(Color.rgb(255,255,255));
				
			}
			else if(founders.getText().equals("Founders of the Festival (show less...)")){
				founders.setText("Founders of the Festival");
				founders1.startAnimation(slide_up);
				
				
			     founders1.postDelayed(new Runnable() {

			        public void run() {
			          
			            founders1.setVisibility(LinearLayout.GONE);
			            founders.setBackgroundColor(Color.rgb(255,255,255));
						founders.setTextColor(Color.rgb(19,18,18));
			          
			        }
			    }, 1000);
			}
			}
		});
}
	
	public void logo(){
		logo.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
			if(logo.getText().equals("Festival Logo")){
				logo.setText("Festival Logo (show less...)");
				logo1.startAnimation(slide_down);
				logo1.setVisibility(LinearLayout.VISIBLE);
				logo.setBackgroundColor(Color.rgb(255,143,60));
				logo.setTextColor(Color.rgb(255,255,255));
				logoPanaad();
				
			}
			else if(logo.getText().equals("Festival Logo (show less...)")){
				logo.setText("Festival Logo");
				logo1.startAnimation(slide_up);
				
				logo1.postDelayed(new Runnable() {

			        public void run() {
			          
			            logo1.setVisibility(LinearLayout.GONE);
			            logo.setBackgroundColor(Color.rgb(255,255,255));
			            logo.setTextColor(Color.rgb(19,18,18));
			        }
			        
				},1000);
				
			}
			}
		});
}
	public void developers(){
		developers.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {

				
				if(developers.getText().equals("Developers")){
					developers.setText("Developers (show less...)");
					developers1.startAnimation(slide_down);
					developers1.setVisibility(LinearLayout.VISIBLE);
					developers.setBackgroundColor(Color.rgb(255,143,60));
					developers.setTextColor(Color.rgb(255,255,255));
					
				}
				else if(developers.getText().equals("Developers (show less...)")){
					developers.setText("Developers");
					developers1.startAnimation(slide_up);
					
					developers1.postDelayed(new Runnable() {

				        public void run() {
				          
				            developers1.setVisibility(LinearLayout.GONE);
				            developers.setBackgroundColor(Color.rgb(255,255,255));
				            developers.setTextColor(Color.rgb(19,18,18));
				        }
				        
					},1000);
				}
				}
		});
}
	public void fb_link(){
		fb.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
                myWebLink.setData(Uri.parse("https://www.facebook.com/PanaadSaNegrosFestival"));
                    startActivity(myWebLink);
                    Toast.makeText(getApplicationContext(), "Linking to facebook", Toast.LENGTH_SHORT).show();
			
			}
		});
}
	public void twitter_link(){
		twitter.setOnClickListener(new View.OnClickListener() {
				
			@Override
			public void onClick(View v) {
				Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
                myWebLink.setData(Uri.parse("https://twitter.com/PanaadSaNegros"));
                    startActivity(myWebLink);
                    Toast.makeText(getApplicationContext(), "Linking to twitter", Toast.LENGTH_SHORT).show();
			}
		});
}
	public void rss_link(){
		rss.setOnClickListener(new View.OnClickListener() {
					
			@Override
			public void onClick(View v) {
				Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
                myWebLink.setData(Uri.parse("https://www.rss.com/"));
                    startActivity(myWebLink);
			Toast.makeText(getApplicationContext(), "Linking to rss feed", Toast.LENGTH_SHORT).show();	
					
			}
		});
}
public void toggle_play(){
		toggle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			/////animation////
				Animation slide_down = AnimationUtils.loadAnimation(getApplicationContext(),
						            R.anim.toggle_down);

				Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
						            R.anim.toggle_up);
				
				Animation rss_down = AnimationUtils.loadAnimation(getApplicationContext(),
			            R.anim.rss_down);
				
				Animation rss_up = AnimationUtils.loadAnimation(getApplicationContext(),
			            R.anim.rss_up);
				
				Animation twit_down = AnimationUtils.loadAnimation(getApplicationContext(),
			            R.anim.twit_down);
				
				Animation twit_up = AnimationUtils.loadAnimation(getApplicationContext(),
			            R.anim.twit_up);
				
if(toggle.getText().equals("-")){
	toggle.setText("+");
					fb.setAnimation(slide_down);
					fb.postDelayed(new Runnable() {

				        public void run() {
				          
				        	fb.setVisibility(Button.GONE);
				          
				        }
				    }, 1000);
					
					
					twitter.setAnimation(twit_down);
					twitter.postDelayed(new Runnable() {

				        public void run() {
				          
				        	twitter.setVisibility(Button.GONE);
				          
				        }
				    }, 1000);
					
					rss.setAnimation(rss_down);
					rss.postDelayed(new Runnable() {

				        public void run() {
				          
				        	rss.setVisibility(Button.GONE);
				          
				        }
				    }, 1000);
					
					
				}
				else if(toggle.getText().equals("+")){
					toggle.setText("-");
					fb.startAnimation(slide_up);
					fb.setVisibility(Button.VISIBLE);
					twitter.startAnimation(twit_up);
					twitter.setVisibility(Button.VISIBLE);
					rss.startAnimation(rss_up);
					rss.setVisibility(Button.VISIBLE);
					
				}
			}
		});
}

public void logoPanaad(){
	founderslogo1.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent i = new Intent(About_Activity.this, LogoActivity.class);
			startActivity(i);
		}
	});
}


}