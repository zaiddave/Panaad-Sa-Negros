package com.chmscalijis.panaadsanegros;

import com.chmscalijis.panaadsanegros.R;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;

public class Email_Activity extends ActionBarActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.emailpage);
		
	}
	

}
