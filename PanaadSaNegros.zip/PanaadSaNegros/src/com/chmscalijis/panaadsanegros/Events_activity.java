
	package com.chmscalijis.panaadsanegros;


	import java.util.ArrayList;
import java.util.Calendar;


	import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.FilterQueryProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chmscalijis.panaadsanegros.events.BackgroundTaskEvents;
import com.chmscalijis.panaadsanegros.events.Events_DatabaseHelper;



	public class Events_activity extends ActionBarActivity{

		private Events_DatabaseHelper db;
		 private SimpleCursorAdapter dataAdapter;
		 Button category;
		 TextView headText;
		 ImageView back,quick_menu;
		 TextView txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8;
		 LinearLayout quick_menuLinear;
		 AutoCompleteTextView myFilter;
		 ArrayAdapter<String> adapter;
		 
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				// TODO Auto-generated method stub
				super.onCreate(savedInstanceState);
				requestWindowFeature(Window.FEATURE_NO_TITLE);
				setContentView(R.layout.lin_ay_layout);
				myFilter = (AutoCompleteTextView) findViewById(R.id.filter);
				myFilter.setAdapter(null);
				quick_menuLinear = (LinearLayout)findViewById(R.id.quick_menuLinear);
				quick_menu = (ImageView)findViewById(R.id.quick_menu);
				category = (Button) findViewById(R.id.category);
				headText = (TextView)findViewById(R.id.headText);
				headText.setText("Events");
				back = (ImageView)findViewById(R.id.back);
				db = new Events_DatabaseHelper(this);
				BackgroundTaskEvents bt = new BackgroundTaskEvents(Events_activity.this);
				bt.execute();
				category.setText("Category: <Select>");
				quick_menuLinear.setVisibility(LinearLayout.GONE);
				txt1 = (TextView)findViewById(R.id.txt1);
				txt2 = (TextView)findViewById(R.id.txt2);
				txt3 = (TextView)findViewById(R.id.txt3);
				txt4 = (TextView)findViewById(R.id.txt4);
				txt5 = (TextView)findViewById(R.id.txt5);
				txt6 = (TextView)findViewById(R.id.txt6);
				txt7 = (TextView)findViewById(R.id.txt7);
				txt8 = (TextView)findViewById(R.id.txt8);
				txt2.setTextColor(Color.rgb(60, 172, 255));
				
				category();
				displayListView();
				back();
				quick();
				empty();
				txt1();
				//txt2();
				txt3();
				txt4();
				txt5();
				txt6();
				txt7();
				txt8();
			}
			public void empty(){
				quick_menuLinear.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						
					}
				});
			}
			public void quick(){
				quick_menu.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(quick_menuLinear.getVisibility() == View.VISIBLE){
						quick_menuLinear.setVisibility(LinearLayout.GONE);
						}
						else{
							quick_menuLinear.setVisibility(LinearLayout.VISIBLE);
						}
					}
				});
			}
			public void txt1(){
				txt1.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),LinAy_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt2(){
				txt2.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),Events_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt3(){
				txt3.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),LGU_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt4(){
				txt4.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),Map_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt5(){
				txt5.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),Incidents_activity.class);
						startActivity(i);
						//finish();
					}
				});
			}
			public void txt6(){
				txt6.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),Winners_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt7(){
				txt7.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),News_activity.class);
						startActivity(i);
						finish();
					}
				});
			}
			public void txt8(){
				txt8.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent i = new Intent(getApplicationContext(),About_Activity.class);
						startActivity(i);
						//finish();
					}
				});
			}
				
			
		  //Generate ListView from SQLite Database
			public void back(){
				back.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						onBackPressed();
					}
				});
			}
			private void displayListView() {
				
				
				Cursor cursor = db.fetchAll();

				  // The desired columns to be bound
				  String[] columns = new String[] {
						  	Events_DatabaseHelper.E_NAME,
						  	Events_DatabaseHelper.E_DATE,
						  	Events_DatabaseHelper.E_VENUE,
							Events_DatabaseHelper.E_YEAR
				  };
				
		 

		 

		  // the XML defined views which the data will be bound to
		  int[] to = new int[] {
			R.id.ename,
		    R.id.edate,
		    R.id.evenue,
		    R.id.eyear
		    
		    
		   
		  };

		  // create the adapter using the cursor pointing to the desired data 
		  //as well as the layout information
		  dataAdapter = new SimpleCursorAdapter(
		    this, R.layout.events_details, 
		    cursor, 
		    columns,
		    to,
		    0);

		  ListView listView = (ListView) findViewById(R.id.listView1);
		  
		  // Assign adapter to ListView
		  listView.setAdapter(dataAdapter);


		  listView.setOnItemClickListener(new OnItemClickListener() {
		   @Override
		   public void onItemClick(AdapterView<?> listView, View view, 
		     int position, long id) {
		   // Get the cursor, positioned to the corresponding row in the result set
		   Cursor cursor = (Cursor) listView.getItemAtPosition(position);

		   // Get the state's capital from this row in the database.
		   int index1 = cursor.getColumnIndexOrThrow("e_name");
		   String str = cursor.getString(index1);
		   Toast.makeText(getApplicationContext(),
		     str, Toast.LENGTH_SHORT).show();

		   }
		  });


		  


			
		  
		  

	  
			  myFilter.addTextChangedListener(new TextWatcher() {

				   public void afterTextChanged(Editable s) {
				   }

				   public void beforeTextChanged(CharSequence s, int start, 
				     int count, int after) {
				   }

				   public void onTextChanged(CharSequence s, int start, 
				     int before, int count) {
				    dataAdapter.getFilter().filter(s.toString());
				   }
				  });
			  
			  dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
			         public Cursor runQuery(CharSequence constraint) {
			             return db.eventName(constraint.toString());
			         }
			     });
			  
			}
			  public void category(){
					category.setOnClickListener(new View.OnClickListener() {
						
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							
							CharSequence filters[] = new CharSequence[] {"Name","Date","Venue"};
							
							AlertDialog.Builder builder = new AlertDialog.Builder(Events_activity.this);
							builder.setTitle("Choose Your Filter:");
							builder.setItems(filters, new DialogInterface.OnClickListener() {

							   
							 public void onClick(DialogInterface dialog, int filter) {
							      
							    	switch (filter) {
							    	
						               case 0:
										            	Toast.makeText(getApplicationContext(), "Filtering: Name... ", Toast.LENGTH_SHORT).show();									        		
										        		category.setText("Category: Name");
										        		myFilter.setAdapter(null);
											      		  myFilter.addTextChangedListener(new TextWatcher() {
											  				
												   			   public void afterTextChanged(Editable s) {
												   			   }
							
												   			   public void beforeTextChanged(CharSequence s, int start, 
												   			     int count, int after) {
												   			   }
							
												   			   public void onTextChanged(CharSequence s, int start, 
												   			     int before, int count) {
												   			    dataAdapter.getFilter().filter(s.toString());
												   			   }
												   			  });
												   		  
												   		  dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
												   		         public Cursor runQuery(CharSequence constraint) {
												   		             return db.eventName(constraint.toString());
												   		         }
												   		     });
										                  break;
						               case 1:
										            	Toast.makeText(getApplicationContext(), "Filtering: Date...", Toast.LENGTH_SHORT).show();
										            	category.setText("Category: Date");
										            	Calendar calendar = Calendar.getInstance();
										        		
										        		int startYear = 1974;
										        		int year = calendar.get(Calendar.YEAR);
										        		ArrayList<String> yearlist = new ArrayList<String>();
										        		
										        		yearlist.add(""+startYear);
										        		while(startYear != year){
										        			startYear = startYear + 1;
										        			yearlist.add(""+startYear);
										        		}
							    	
										        		adapter =new ArrayAdapter<String>(Events_activity.this,android.R.layout.select_dialog_item,yearlist);
										        		myFilter.setThreshold(1);
										        		myFilter.setAdapter(adapter);
										        		myFilter.addTextChangedListener(new TextWatcher() {
											  				
												   			   public void afterTextChanged(Editable s) {
												   			   }
							
												   			   public void beforeTextChanged(CharSequence s, int start, 
												   			     int count, int after) {
												   			   }
							
												   			   public void onTextChanged(CharSequence s, int start, 
												   			     int before, int count) {
												   			    dataAdapter.getFilter().filter(s.toString());
												   			   }
												   			  });
												   		  
												   		  dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
												   		         public Cursor runQuery(CharSequence constraint) {
												   		             return db.eventDate(constraint.toString());
												   		         }
												   		     });
										        
											              break;
						               case 2:
										            	Toast.makeText(getApplicationContext(), "Filtering: Venue...", Toast.LENGTH_SHORT).show();
										            	category.setText("Category: Venue");									            								            	
										            	myFilter.setAdapter(null);
										            	myFilter.addTextChangedListener(new TextWatcher() {
											  				
												   			   public void afterTextChanged(Editable s) {
												   			   }
							
												   			   public void beforeTextChanged(CharSequence s, int start, 
												   			     int count, int after) {
												   			   }
							
												   			   public void onTextChanged(CharSequence s, int start, 
												   			     int before, int count) {
												   			    dataAdapter.getFilter().filter(s.toString());
												   			   }
												   			  });
												   		  
												   		  dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
												   		         public Cursor runQuery(CharSequence constraint) {
												   		             return db.eventVenue(constraint.toString());
												   		         }
												   		     });
					
										            	break;
						               default:
								      		  myFilter.addTextChangedListener(new TextWatcher() {
								  				
									   			   public void afterTextChanged(Editable s) {
									   			   }
				
									   			   public void beforeTextChanged(CharSequence s, int start, 
									   			     int count, int after) {
									   			   }
				
									   			   public void onTextChanged(CharSequence s, int start, 
									   			     int before, int count) {
									   			    dataAdapter.getFilter().filter(s.toString());
									   			   }
									   			  });
									   		  
									   		  dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
									   		         public Cursor runQuery(CharSequence constraint) {
									   		             return db.eventName(constraint.toString());
									   		         }
									   		     });
						            	   				break;
						            }
							    }
							});
							builder.show();

						}
					});

				}

		
		
			
			  
	
}
