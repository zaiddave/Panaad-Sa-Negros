package com.chmscalijis.panaadsanegros;

import android.support.v7.app.ActionBarActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.*;


public class Incidents_activity extends ActionBarActivity {
Button police,fire,hospital,call;
EditText txt1;
LinearLayout dialLinear;
ImageView back,showDial;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.incidents_layout);
        call = (Button)findViewById(R.id.button4);
        police = (Button)findViewById(R.id.button3);
        fire = (Button)findViewById(R.id.button1);
        hospital = (Button)findViewById(R.id.button2);
        txt1 = (EditText)findViewById(R.id.editText1);
        back = (ImageView)findViewById(R.id.back);
        showDial = (ImageView)findViewById(R.id.showDial);
        dialLinear = (LinearLayout)findViewById(R.id.dialLinear);
        /////
        dialLinear.setVisibility(LinearLayout.GONE);
        back();
        police();
        fire();
        hospital();
        dial();
        showDial();
    }
public void showDial(){
    showDial.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			if(dialLinear.getVisibility() == View.VISIBLE){
			  dialLinear.setVisibility(LinearLayout.GONE);
		}else{
			 dialLinear.setVisibility(LinearLayout.VISIBLE);
		}
		}
	});	
    }
    
    public void dial(){
    call.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			String angnumber = txt1.getText().toString();
			Intent callIntent = new Intent(Intent.ACTION_CALL);
     	   callIntent.setData(Uri.parse("tel:"+angnumber));
				startActivity(callIntent);
				Toast.makeText(getApplicationContext(), "Calling",Toast.LENGTH_SHORT).show();
		}
	});	
    }
    public void police(){
    police.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			CharSequence colors[] = new CharSequence[] {"Station1\n[San Juan Street]: (034)434-5001","Station2\n[19th Street]: (034)434-8177","Station3\n[Mandalagan]: (034)707-8058","Station4\n[Villamonte]: (034)433-5041","Station5\n[Granada]: (034)708-8291","Station6\n[Taculing]: (034)468-0341","Station7\n[Mansilingan]: (034)446-2595","Station8\n[Tangub]: (034)444-1593","Station9\n[Sum-ag]: (034)444-0770","Emergency Hotline\n[BCPO Headquarters]: 117","BCPO Headquarters\n[Taculing]: (034)432-1865"};
			
			AlertDialog.Builder builder = new AlertDialog.Builder(Incidents_activity.this);
			builder.setTitle("Bacolod List Of Police Stations:");
			builder.setItems(colors, new DialogInterface.OnClickListener() {
				 Intent callIntent = new Intent(Intent.ACTION_CALL);
				 
			    @Override
			   
			    public void onClick(DialogInterface dialog, int which) {
			        // the user clicked on colors[which]
			    	String tel1,tel2,tel3,tel4,tel5,tel6,tel7,tel8,tel9,tel10,tel11;
			    	switch (which) {
			    	 
		               case 0:
							tel1 = "0344345001";
		            	   callIntent.setData(Uri.parse("tel:"+tel1));
		    				startActivity(callIntent);
		                  break;
		               case 1:
		            	   tel2 = "0344345001";
		    				callIntent.setData(Uri.parse("tel:"+tel2));
		    				startActivity(callIntent);
		                  break;
		               case 2:
							tel3 = "0347078058";
							
		            	   callIntent.setData(Uri.parse("tel:"+tel3));
		    				startActivity(callIntent);
		                  break;
		               case 3:
		            	   tel4 = "0344335041";
		    				callIntent.setData(Uri.parse("tel:"+tel4));
		    				startActivity(callIntent);
		                  break;
		               case 4:
							tel5 = "0347088291";
							
		            	   callIntent.setData(Uri.parse("tel:"+tel5));
		    				startActivity(callIntent);
		                  break;
		               case 5:
		            	   tel6 = "0344680341";
		    				callIntent.setData(Uri.parse("tel:"+tel6));
		    				startActivity(callIntent);
		                  break;
		               case 6:
							tel7 = "0344462595";
							
		            	   callIntent.setData(Uri.parse("tel:"+tel7));
		    				startActivity(callIntent);
		                  break;
		               case 7:
		            	   tel8 = "0344441593";
		    				callIntent.setData(Uri.parse("tel:"+tel8));
		    				startActivity(callIntent);
		                  break;
		               case 8:
							tel9 = "0344440770";
							
		            	   callIntent.setData(Uri.parse("tel:"+tel9));
		    				startActivity(callIntent);
		                  break;
		               case 9:
		            	   tel10 = "117";
		    				callIntent.setData(Uri.parse("tel:"+tel10));
		    				startActivity(callIntent);
		                  break;
		               case 10:
		            	   tel11 = "0344321865";
		    				callIntent.setData(Uri.parse("tel:"+tel11));
		    				startActivity(callIntent);
		                  break;
		               default:
		                    break;
		            }
			    }
			});
			builder.show();
		}
	});
    }
    public void fire(){
    fire.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			CharSequence colors[] = new CharSequence[] {"San Juan Fire Station(1) \n (034)4335022","San Juan Fire Station(2) \n (034)4335023","Lopez Jaena Station \n (034)4345021","Libertad Sub-Station \n (034)4342707","Amity Volunteer Brigade \n 161","Chamber Volunteer Brigade \n 164"};
			
			AlertDialog.Builder builder = new AlertDialog.Builder(Incidents_activity.this);
			builder.setTitle("Bacolod List Of Fire Stations:");
			builder.setItems(colors, new DialogInterface.OnClickListener() {
				 Intent callIntent = new Intent(Intent.ACTION_CALL);
				 
			    @Override
			   
			    public void onClick(DialogInterface dialog, int which) {
			        // the user clicked on colors[which]
			    	String tel1,tel2,tel3,tel4,tel5,tel6;
			    	switch (which) {
			    	 
		               case 0:
							tel1 = "0344345022";
		            	   callIntent.setData(Uri.parse("tel:"+tel1));
		    				startActivity(callIntent);
		                  break;
		               case 1:
		            	   tel2 = "0344345023";
		    				callIntent.setData(Uri.parse("tel:"+tel2));
		    				startActivity(callIntent);
		    				Toast.makeText(getApplicationContext(), tel2, Toast.LENGTH_SHORT).show();
		                  break;
		               case 2:
							tel3 = "0344345021";
		            	   callIntent.setData(Uri.parse("tel:"+tel3));
		    				startActivity(callIntent);
		                  break;
		               case 3:
		            	   tel4 = "0344342707";
		    				callIntent.setData(Uri.parse("tel:"+tel4));
		    				startActivity(callIntent);
		                  break;
		               case 4:
							tel5 = "161";
		            	   callIntent.setData(Uri.parse("tel:"+tel5));
		    				startActivity(callIntent);
		                  break;
		               case 5:
		            	   tel6 = "164";
		    				callIntent.setData(Uri.parse("tel:"+tel6));
		    				startActivity(callIntent);
		                  break;
		               default:
		                    break;
		            }
			    }
			});
			builder.show();
		}
	});
    }
    public void hospital(){
  	hospital.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			CharSequence colors[] = new CharSequence[] {"LN Agustin Memorial Hospital \n (034)4341031","Adventist Medical Center(1) \n (034)4334831","Adventist Medical Center(2) \n (034)4334832","Adventist Medical Center(3) \n (034)4334833","Adventist Medical Center(4) \n (034)4334834","Adventist Medical Center(5) \n (034)4334835","Adventist Medical Center(6) \n (034)4334836","Doctor's Hospital \n (034)4332741","Riverside Medical Center \n (034)4337331"};
			
			AlertDialog.Builder builder = new AlertDialog.Builder(Incidents_activity.this);
			builder.setTitle("Bacolod List of Hospitals:");
			builder.setItems(colors, new DialogInterface.OnClickListener() {
				 Intent callIntent = new Intent(Intent.ACTION_CALL);
				 
			    @Override
			   
			    public void onClick(DialogInterface dialog, int which) {
			        // the user clicked on colors[which]
			    	String tel1,tel2,tel3,tel4,tel5,tel6,tel7,tel8,tel9;
			    	switch (which) {
			    	 
		               case 0:
		            	   tel1 = "0344341031";
							callIntent.setData(Uri.parse("tel:"+tel1));
		    				startActivity(callIntent);
		                  break;
		               case 1:
		            	   tel2 = "0344334831";
		    				callIntent.setData(Uri.parse("tel:"+tel2));
		    				startActivity(callIntent);
		                  break;
		               case 2:
		            	   tel3 = "0344334832";
							callIntent.setData(Uri.parse("tel:"+tel3));
		    				startActivity(callIntent);
		                  break;
		               case 3:
		            	   tel4 = "0344334833";
		    				callIntent.setData(Uri.parse("tel:"+tel4));
		    				startActivity(callIntent);
		                  break;
		               case 4:
		            	   tel5 = "0344334834";
							callIntent.setData(Uri.parse("tel:"+tel5));
		    				startActivity(callIntent);
		                  break;
		               case 5:
		            	   tel6 = "0344334835";
		    				callIntent.setData(Uri.parse("tel:"+tel6));
		    				startActivity(callIntent);
		                  break;
		               case 6:
		            	   tel7 = "0344334836";
		    				callIntent.setData(Uri.parse("tel:"+tel7));
		    				startActivity(callIntent);
		                  break;
		               case 7:
		            	   tel8 = "0344332741";
		    				callIntent.setData(Uri.parse("tel:"+tel8));
		    				startActivity(callIntent);
		                  break;
		               case 8:
		            	   tel9 = "0344337331";
		    				callIntent.setData(Uri.parse("tel:"+tel9));
		    				startActivity(callIntent);
		                  break;
		               default:
		                    break;
		            }
			    }
			});
			builder.show();
		}
	});
    }
    public void back(){
    	back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onBackPressed();
			}
		});
    }

    
}
