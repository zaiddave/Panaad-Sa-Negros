package com.chmscalijis.panaadsanegros;



import com.chmscalijis.panaadsanegros.R;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.widget.Button;


public class MainActivity extends ActionBarActivity {
Button lin_ay,event,lgu,locator,incident,winner,news,about;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);   
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        lin_ay = (Button)findViewById(R.id.lin_ay);
        event = (Button)findViewById(R.id.events);
        lgu= (Button)findViewById(R.id.lgu);
        locator = (Button)findViewById(R.id.locator);
        incident= (Button)findViewById(R.id.incident);
        winner = (Button)findViewById(R.id.winner);
        news = (Button)findViewById(R.id.news);
        about = (Button)findViewById(R.id.about);
        
        
        
        goto_linay();
        goto_about();
        goto_event();
        goto_lgu();
        goto_winners();
        goto_news();
        goto_incident();
        goto_map();
        
    }
    public void goto_map(){
    	locator.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,Map_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }
public void goto_incident(){
    	incident.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,Incidents_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }
public void goto_winners(){
    	winner.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,Winners_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }
    
public void goto_news(){
    	news.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,News_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }
    
   
public void goto_lgu(){
    	lgu.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,LGU_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }    

public void goto_event(){
    	event.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			Intent i = new Intent(MainActivity.this,Events_activity.class);
    			startActivity(i);
    			
    		}
    	});
    }
public void goto_linay(){
	lin_ay.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent i = new Intent(MainActivity.this, LinAy_activity.class);
			startActivity(i);
			
		}
	});
}
public void goto_about(){
	about.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent i = new Intent(MainActivity.this, About_Activity.class);
			startActivity(i);
		}
	});
}
   
}
