package com.chmscalijis.panaadsanegros;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;


public class Map_activity extends ActionBarActivity {

LinearLayout baseLinear;
ImageView back,map_menu;

@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.map_layout);
        
        baseLinear = (LinearLayout)findViewById(R.id.baseOnLinear);
        baseLinear.setVisibility(LinearLayout.GONE);
        
        back = (ImageView)findViewById(R.id.backMap);
        map_menu = (ImageView)findViewById(R.id.baseOn);
            	
        mapin();
        back();

    }
	public void mapin(){
	map_menu.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(baseLinear.getVisibility() == View.VISIBLE){
				baseLinear.setVisibility(LinearLayout.GONE);
			}
			else{
				baseLinear.setVisibility(LinearLayout.VISIBLE);
			}
			}
		
	});
	
	}	
    public void back(){
    	back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onBackPressed();
			}
		});
    }


}
