package com.chmscalijis.panaadsanegros.events;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class Events_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "event";
		public static final int DBVERSION = 1;
		public static final String E_NAME = "e_name";
		public static final String E_ID = "e_id";
		public static final String E_DATE= "e_date";
		public static final String E_VENUE= "e_venue";
		public static final String E_YEAR= "e_year";
		
		;
		
		public Events_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+E_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+E_NAME+" TEXT, "+E_DATE+" TEXT, "+E_VENUE+" TEXT,"+E_YEAR+" TEXT)");
			Log.d("Database operation", "Table created...");
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+E_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+E_NAME+" TEXT, "+E_DATE+" TEXT, "+E_VENUE+" TEXT,"+E_YEAR+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
		/**		
		public void putAllJava( DataModel datamodel ) {
			SQLiteDatabase db = this.getWritableDatabase();
			
			ContentValues db_values = new ContentValues();
			
			db_values.put(L_NAME, datamodel.getName());
			db_values.put(L_AGE, datamodel.getAge());
			db_values.put(L_ADD, datamodel.getAdd());
			
			
			db.insert(TBL, null, db_values);
			
			db.close();
		}
			
			 	
	
		public Cursor getAllDataModel(){
			
			List<DataModel> dataList = new ArrayList<DataModel>();
			String query = "SELECT * FROM " + TBL;
			
			SQLiteDatabase db = this.getWritableDatabase();
			Cursor c = db.rawQuery(query, null);
			
			while(c.moveToNext()){
				
				int index0 = c.getColumnIndex(L_ID);
				int index1 = c.getColumnIndex(L_NAME);
				int index2 = c.getColumnIndex(L_AGE);
				int index3 = c.getColumnIndex(L_ADD);
				
				
				int id = c.getInt(index0);
				
				String name = c.getString(index1);
				String age = c.getString(index2);
				String add = c.getString(index3);
				
				DataModel model = new DataModel(id, name, age, add);
				dataList.add(model);
								
			}
			
			return (Cursor) dataList;
		}	
		
	**/
		 
		
  public long putAllJava(String name, String date, String venue, String year) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(E_NAME, name);  
  cv.put(E_DATE, date);
  cv.put(E_VENUE, venue);
  cv.put(E_YEAR, year);
  
  
  return db.insert(TBL, null, cv);
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", E_ID,
					  E_NAME, E_DATE, E_VENUE,E_YEAR}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	public void deleteJavaTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+E_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+E_NAME+" TEXT, "+E_DATE+" TEXT, "+E_VENUE+" TEXT,"+E_YEAR+" TEXT)");
		Log.d("Updating Table", "Updating...");
  		 db.close();
  	
}
  	
  	public Cursor eventName(String inputText) throws SQLException {
  	  //Log.w(TAG, inputText);
  	  SQLiteDatabase db = this.getWritableDatabase();
  	  Cursor mCursor = null;
  	  if (inputText == null  ||  inputText.length () == 0)  {
  		mCursor = db.query(TBL, new String[] {"rowid _id", E_ID,
				  E_NAME, E_DATE, E_VENUE,E_YEAR}, 
		    null, null, null, null, null);

  	  }
  	  else {
  	   mCursor = db.query(true, TBL, new String[] {"rowid _id", E_ID,
				  E_NAME, E_DATE, E_VENUE,E_YEAR},  
  	     E_NAME + " like '%" + inputText + "%'", null,
  	     null, null, null, null);
  	  }
  	  if (mCursor != null) {
  	   mCursor.moveToFirst();
  	  }
  	  return mCursor;

  	 }
  	
  	public Cursor eventVenue(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    		  mCursor = db.query(true, TBL, new String[] {"rowid _id", E_ID,
    				  E_NAME, E_DATE, E_VENUE,E_YEAR},  
      	     E_VENUE + " like '%" + inputText + "%'", null,
      	     null, null, null, null);

    	  }
    	  else {
    		  mCursor = db.query(true, TBL, new String[] {"rowid _id", E_ID,
    				  E_NAME, E_DATE, E_VENUE,E_YEAR},  
      	     E_VENUE + " like '%" + inputText + "%'", null,
      	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
  	
  	
  	
  	public Cursor eventDate(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    		  mCursor = db.query(true, TBL, new String[] {"rowid _id", E_ID,
    				  E_NAME, E_DATE, E_VENUE,E_YEAR},  
      	     E_DATE + " like '%" + inputText + "%'", null,
      	     null, null, null, null);

    	  }    	  else {
    		  mCursor = db.query(true, TBL, new String[] {"rowid _id", E_ID,
    				  E_NAME, E_DATE, E_VENUE,E_YEAR},   
    	    E_DATE + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
}

