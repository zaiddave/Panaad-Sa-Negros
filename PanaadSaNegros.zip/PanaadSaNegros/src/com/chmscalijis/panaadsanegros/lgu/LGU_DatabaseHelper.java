package com.chmscalijis.panaadsanegros.lgu;

import java.util.ArrayList;

import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class LGU_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "lgu";
		public static final int DBVERSION = 1;
		public static final String LGU_ID = "lgu_id";
		public static final String LGU_CITY = "lgu_city";
		public static final String LGU_DESC = "lgu_desc";
		public static final String LGU_PROD= "lgu_prod";
		public static final String LGU_TRIVIA= "lgu_trivia";
		public static final String LGU_IMAGE= "lgu_image";
		
		;
		
		

		public LGU_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE "+TBL +" ("+LGU_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+LGU_CITY+" TEXT, "+LGU_DESC+" TEXT, "+LGU_PROD+" TEXT,"+LGU_TRIVIA+" TEXT,"+LGU_IMAGE+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
		 
		
  public long putAllJava(String city, String desc, String prod, String trivia, String image) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(LGU_CITY, city);  
  cv.put(LGU_DESC, desc);
  cv.put(LGU_PROD, prod);
  cv.put(LGU_TRIVIA, trivia);
  cv.put(LGU_IMAGE, image);
  
  
  return db.insert(TBL, null, cv);
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", LGU_ID,
					  LGU_CITY, LGU_DESC, LGU_PROD,LGU_TRIVIA,LGU_IMAGE}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	public void deleteTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE "+TBL +" ("+LGU_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+LGU_CITY+" TEXT, "+LGU_DESC+" TEXT, "+LGU_PROD+" TEXT,"+LGU_TRIVIA+" TEXT, "+LGU_IMAGE+" TEXT)");
  			Log.d("Updating Table", "Updating...");
  		 db.close();
  	
}
  	
  	public Cursor lguCity(String inputText) throws SQLException {
  	  //Log.w(TAG, inputText);
  	  SQLiteDatabase db = this.getWritableDatabase();
  	  Cursor mCursor = null;
  	  if (inputText == null  ||  inputText.length () == 0)  {
  	   mCursor = db.query(TBL, new String[] {"rowid _id", LGU_ID,
  			 LGU_CITY, LGU_DESC, LGU_PROD,LGU_TRIVIA,LGU_IMAGE}, 
  	     null, null, null, null, null);

  	  }
  	  else {
  	   mCursor = db.query(true, TBL, new String[] {"rowid _id", LGU_ID,
  			 LGU_CITY, LGU_DESC,LGU_PROD,LGU_TRIVIA,LGU_IMAGE}, 
  			LGU_CITY + " like '%" + inputText + "%'", null,
  	     null, null, null, null);
  	  }
  	  if (mCursor != null) {
  	   mCursor.moveToFirst();
  	  }
  	  return mCursor;

  	 }
  	
  	public Cursor lguProduct(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", LGU_ID,
    			   LGU_CITY, LGU_DESC, LGU_PROD,LGU_TRIVIA,LGU_IMAGE}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", LGU_ID,
    			   LGU_CITY, LGU_DESC, LGU_PROD,LGU_TRIVIA,LGU_IMAGE}, 
    			   LGU_PROD + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

  	}
}
  	

