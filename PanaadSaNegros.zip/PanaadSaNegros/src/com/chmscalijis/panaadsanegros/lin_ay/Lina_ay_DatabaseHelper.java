package com.chmscalijis.panaadsanegros.lin_ay;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class Lina_ay_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "linay";
		public static final int DBVERSION = 1;
		public static final String L_NAME = "l_name";
		public static final String L_ID = "_id";
		public static final String L_CITY= "l_city";
		public static final String L_DESC= "l_desc";
		public static final String L_IMAGE= "l_image";
		public static final String L_AGE= "l_age";
		public static final String L_COM= "l_com";
		
		;
		
		

		public Lina_ay_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+L_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+L_CITY+" TEXT, "+L_NAME+" TEXT, "+L_AGE+" TEXT,"+L_DESC+" TEXT, "+L_COM+" TEXT,"+L_IMAGE+" TEXT)");
			Log.d("Database operation", "Table created...");
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE "+TBL +" ("+L_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+L_CITY+" TEXT, "+L_NAME+" TEXT, "+L_AGE+" TEXT,"+L_DESC+" TEXT, "+L_COM+" TEXT,"+L_IMAGE+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
		/**		
		public void putAllJava( DataModel datamodel ) {
			SQLiteDatabase db = this.getWritableDatabase();
			
			ContentValues db_values = new ContentValues();
			
			db_values.put(L_NAME, datamodel.getName());
			db_values.put(L_AGE, datamodel.getAge());
			db_values.put(L_ADD, datamodel.getAdd());
			
			
			db.insert(TBL, null, db_values);
			
			db.close();
		}
			
			 	
	
		public Cursor getAllDataModel(){
			
			List<DataModel> dataList = new ArrayList<DataModel>();
			String query = "SELECT * FROM " + TBL;
			
			SQLiteDatabase db = this.getWritableDatabase();
			Cursor c = db.rawQuery(query, null);
			
			while(c.moveToNext()){
				
				int index0 = c.getColumnIndex(L_ID);
				int index1 = c.getColumnIndex(L_NAME);
				int index2 = c.getColumnIndex(L_AGE);
				int index3 = c.getColumnIndex(L_ADD);
				
				
				int id = c.getInt(index0);
				
				String name = c.getString(index1);
				String age = c.getString(index2);
				String add = c.getString(index3);
				
				DataModel model = new DataModel(id, name, age, add);
				dataList.add(model);
								
			}
			
			return (Cursor) dataList;
		}	
		
	**/
		 
		
  public long putAllJava(String name, String city, String age, String desc, String com, String image) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(L_NAME, name);  
  cv.put(L_AGE, age);
  cv.put(L_CITY, city);
  cv.put(L_DESC, desc);
  cv.put(L_COM, com);
  cv.put(L_IMAGE, image);
  
  return db.insert(TBL, null, cv);
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", L_ID,
					  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	public void deleteJavaTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE "+TBL +" ("+L_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+L_CITY+" TEXT, "+L_NAME+" TEXT, "+L_AGE+" TEXT,"+L_DESC+" TEXT, "+L_COM+" TEXT,"+L_IMAGE+" TEXT)");
  			Log.d("Updating Table", "Updating...");
  		 db.close();
  	
}
  	
  	public Cursor fetchName(String inputText) throws SQLException {
  	  //Log.w(TAG, inputText);
  	  SQLiteDatabase db = this.getWritableDatabase();
  	  Cursor mCursor = null;
  	  if (inputText == null  ||  inputText.length () == 0)  {
  	   mCursor = db.query(TBL, new String[] {"rowid _id", L_ID,
				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
  	     null, null, null, null, null);

  	  }
  	  else {
  	   mCursor = db.query(true, TBL, new String[] {"rowid _id", L_ID,
				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
  	     L_NAME + " like '%" + inputText + "%'", null,
  	     null, null, null, null);
  	  }
  	  if (mCursor != null) {
  	   mCursor.moveToFirst();
  	  }
  	  return mCursor;

  	 }
  	
  	public Cursor fetchYear(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", L_ID,
  				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", L_ID,
  				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
    	     L_COM + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
  	
  	
  	
  	public Cursor fetchCity(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", L_ID,
  				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", L_ID,
  				  L_NAME, L_AGE, L_CITY,L_DESC,L_COM,L_IMAGE}, 
    	     L_CITY + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
}

