package com.chmscalijis.panaadsanegros.message;

public class MessageModel {
	
	int _id;
	String Name;
	String Dgn;
	String Cntnt;
	
	//empty constructor
    public MessageModel(){
        
    }
    
    // constructor w/ id
    public MessageModel(int id, String name, String dgn, String cntnt){
        this._id = id;
        this.Name = name;
        this.Dgn = dgn;
        this.Cntnt = cntnt;
    }
     
    // constructor w/o id
    public MessageModel( String name, String dgn, String cntnt){
    	this.Name = name;
        this.Dgn = dgn;
        this.Cntnt = cntnt;
    }
	
    //getter and setter
    
	public int get_id() {
		return _id;
	}
	public void set_id(int _id) {
		this._id = _id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDgn() {
		return Dgn;
	}
	public void setDgn(String dgn) {
		Dgn = dgn;
	}
	public String getCntnt() {
		return Cntnt;
	}
	public void setCntnt(String cntnt) {
		Cntnt = cntnt;
	}

}
