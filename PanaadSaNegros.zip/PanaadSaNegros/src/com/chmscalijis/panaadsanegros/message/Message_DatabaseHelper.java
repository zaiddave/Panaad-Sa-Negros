package com.chmscalijis.panaadsanegros.message;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class Message_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "message";
		public static final int DBVERSION = 1;
		public static final String M_NAME = "m_name";
		public static final String M_ID = "_id";
		public static final String M_CONTENT= "m_content";
		public static final String M_DESIGNATION= "m_designation";
		
		;
		
		

		public Message_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+M_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+M_NAME+" TEXT, "+M_CONTENT+" TEXT, "+M_DESIGNATION+" TEXT)");
			Log.d("Database operation", "Table created...");
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE "+TBL +" ("+M_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+M_NAME+" TEXT, "+M_CONTENT+" TEXT, "+M_DESIGNATION+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
			 
		
  public void  putAll(MessageModel msg) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(M_NAME, msg.getName());  
  cv.put(M_DESIGNATION, msg.getDgn());
  cv.put(M_CONTENT, msg.getCntnt());
  
  db.insert(TBL, null, cv);
  db.close();
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", M_ID,
					  M_NAME, M_CONTENT, M_DESIGNATION}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	
  	
  	
  	
  	
  	public void deleteTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE "+TBL +" ("+M_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+M_NAME+" TEXT, "+M_CONTENT+" TEXT, "+M_DESIGNATION+" TEXT)");
  			Log.d("Updating Table", "Updating...");
  		 db.close();  	
}
  	
	 	
	}

