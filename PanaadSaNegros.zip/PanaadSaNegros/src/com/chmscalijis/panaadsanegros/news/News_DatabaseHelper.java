package com.chmscalijis.panaadsanegros.news;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class News_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "news";
		public static final int DBVERSION = 1;
		public static final String N_TITLE = "n_title";
		public static final String N_ID = "_id";
		public static final String N_CONTENT= "n_content";
		public static final String N_SOURCE= "n_source";
		
		;
		
		

		public News_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+N_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+N_TITLE+" TEXT, "+N_CONTENT+" TEXT, "+N_SOURCE+" TEXT)");
			Log.d("Database operation", "Table created...");
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE "+TBL +" ("+N_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+N_TITLE+" TEXT, "+N_CONTENT+" TEXT, "+N_SOURCE+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
			 
		
  public long putAll(String title, String content, String source) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(N_TITLE, title);  
  cv.put(N_CONTENT, content);
  cv.put(N_SOURCE, source);
  
  return db.insert(TBL, null, cv);
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", N_ID,
					  N_TITLE, N_CONTENT, N_SOURCE}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	public void deleteTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE "+TBL +" ("+N_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+N_TITLE+" TEXT, "+N_CONTENT+" TEXT, "+N_SOURCE+" TEXT)");
  			Log.d("Updating Table", "Updating...");
  		 db.close();
  	
}
  	
  	public Cursor fetchTitle(String inputText) throws SQLException {
  	  //Log.w(TAG, inputText);
  	  SQLiteDatabase db = this.getWritableDatabase();
  	  Cursor mCursor = null;
  	  if (inputText == null  ||  inputText.length () == 0)  {
  	   mCursor = db.query(TBL, new String[] {"rowid _id", N_ID,
  			 N_TITLE, N_CONTENT, N_SOURCE}, 
  	     null, null, null, null, null);

  	  }
  	  else {
  	   mCursor = db.query(true, TBL, new String[] {"rowid _id", N_ID,
  			 N_TITLE, N_CONTENT, N_SOURCE}, 
  			N_TITLE + " like '%" + inputText + "%'", null,
  	     null, null, null, null);
  	  }
  	  if (mCursor != null) {
  	   mCursor.moveToFirst();
  	  }
  	  return mCursor;

  	 }
  	
  	public Cursor fetchSource(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", N_ID,
    			   N_TITLE,N_CONTENT, N_SOURCE}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", N_ID,
    			   N_TITLE,N_CONTENT, N_SOURCE}, 
    	     N_SOURCE + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
  	
  	
  	
  	}

