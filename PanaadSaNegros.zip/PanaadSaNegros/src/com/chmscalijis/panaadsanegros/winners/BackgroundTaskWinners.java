package com.chmscalijis.panaadsanegros.winners;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

public class BackgroundTaskWinners extends AsyncTask<Void, Void, Void>{
	ProgressDialog pd;
	Context cxt;
	String json_url = "http://10.0.2.2/trial/winners.php";
	//String json_url = "http://192.168.27.1/trial/winners.php";
	
	public BackgroundTaskWinners(Context cxt){
		this.cxt = cxt;
	}
	
	@Override
	protected void onPreExecute(){
		super.onPreExecute();
		pd = new ProgressDialog(cxt);
		pd.setIndeterminate(true);
		pd.setTitle("Please wait...");
		pd.setMessage("Download in progress...");
		pd.setCancelable(false);
		pd.show();	
	}
	

	
	
	@Override
	protected Void doInBackground(Void... params){
		try{
			URL url = new URL(json_url);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			InputStream inputStream = con.getInputStream();
			BufferedReader bf = new BufferedReader(new InputStreamReader(inputStream));
			StringBuilder stringBuilder =  new StringBuilder();
			String line;
			
			while((line=bf.readLine())!=null){
				stringBuilder.append(line+"\n");
				Thread.sleep(500);
			}
			
			con.disconnect();
			String json_data = stringBuilder.toString().trim();
			JSONObject jsonObject = new JSONObject(json_data);
			JSONArray jsonArray = jsonObject.getJSONArray("server_response");
			Winners_DatabaseHelper db = new Winners_DatabaseHelper(cxt);
			
			db.deleteTable();
			//SQLiteDatabase db = jdb.getWritableDatabase();

			int count = 0;
			while (count < jsonArray.length()){
				
				JSONObject ob = jsonArray.getJSONObject(count);
				count++;
				
				db.putAll(ob.getString("Competition"),ob.getString("Winner"), ob.getString("City"),ob.getString("Rank"),ob.getString("Prize"),ob.getString("Coordinator"),ob.getString("Position"),ob.getString("Year"));
				Log.d("Inserting", ob.getString("Winner"));
				
			}		
			db.close();		
		}catch(MalformedURLException e){
			e.printStackTrace();
			
		}catch(IOException e){
			e.printStackTrace();
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	@Override
	protected void onProgressUpdate(Void... values){
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPostExecute(Void aVoid){
		pd.dismiss();
	}
	
}

