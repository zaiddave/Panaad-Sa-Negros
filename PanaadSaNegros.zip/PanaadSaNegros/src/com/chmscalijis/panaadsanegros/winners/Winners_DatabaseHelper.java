package com.chmscalijis.panaadsanegros.winners;

import java.util.ArrayList;
import java.util.List;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


	public class Winners_DatabaseHelper extends SQLiteOpenHelper {
		
		public static final String DBASE = "Panaad";
		public static final String TBL = "winners";
		public static final int DBVERSION = 1;
		public static final String W_ID = "w_id";
		public static final String W_COMPETITION = "w_competition";
		public static final String W_WINNER = "w_winner";
		public static final String W_CITY= "w_city";
		public static final String W_RANK= "w_rank";
		public static final String W_PRIZE= "w_prize";
		public static final String W_COORDINATOR= "w_coordinator";
		public static final String W_POSITION= "w_position";
		public static final String W_YEAR= "w_year";
		
		;
		
		

		public Winners_DatabaseHelper(Context context) {
			super(context, DBASE, null, DBVERSION);
			// TODO Auto-generated constructor stub
			SQLiteDatabase db = this.getWritableDatabase();
			Log.d("Database operation","Database created...");
			db.execSQL("CREATE TABLE IF NOT EXISTS "+TBL +" ("+W_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+W_COMPETITION+" TEXT, "+W_WINNER+" TEXT, "+W_CITY+" TEXT,"+W_RANK+" TEXT, "+W_PRIZE+" TEXT,"+W_COORDINATOR+" TEXT,"+W_POSITION+" TEXT,"+W_YEAR+" TEXT)");
			Log.d("Database operation", "Table created...");
			
			
			
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE "+TBL +" ("+W_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+W_COMPETITION+" TEXT, "+W_WINNER+" TEXT, "+W_CITY+" TEXT,"+W_RANK+" TEXT, "+W_PRIZE+" TEXT,"+W_COORDINATOR+" TEXT,"+W_POSITION+" TEXT,"+W_YEAR+" TEXT)");
			Log.d("Database operation", "Table created...");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS "+TBL);
			Log.d("Database operation", "Database updated...");
			
			onCreate(db);
		}
		
		 
		
  public long putAll(String competition, String winner, String city, String rank, String prize, String coordinator, String position, String year) {
	   SQLiteDatabase db = this.getWritableDatabase();

  ContentValues cv = new ContentValues();
  cv.put(W_COMPETITION, competition);  
  cv.put(W_WINNER, winner);
  cv.put(W_CITY, city);
  cv.put(W_RANK, rank);
  cv.put(W_PRIZE, prize);
  cv.put(W_COORDINATOR, coordinator);
  cv.put(W_POSITION, position);
  cv.put(W_YEAR, year);
  
  return db.insert(TBL, null, cv);
  
  
 }
   
  	public Cursor fetchAll() {
			SQLiteDatabase db = this.getReadableDatabase();
			
			  Cursor mCursor = db.query(TBL, new String[] {"rowid _id", W_ID,
					  W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR, W_POSITION, W_YEAR}, 
			    null, null, null, null, null);

			  if (mCursor != null) {
			   mCursor.moveToFirst();
			  }
			  return mCursor;
	}
  	
  	public void deleteTable(){
  		 SQLiteDatabase db = this.getWritableDatabase();
  		 db.execSQL("DROP TABLE IF EXISTS "+TBL);
  		db.execSQL("CREATE TABLE "+TBL +" ("+W_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+W_COMPETITION+" TEXT, "+W_WINNER+" TEXT, "+W_CITY+" TEXT,"+W_RANK+" TEXT, "+W_PRIZE+" TEXT,"+W_COORDINATOR+" TEXT,"+W_POSITION+" TEXT,"+W_YEAR+" TEXT)");
  			Log.d("Updating Table", "Updating...");
  		 db.close();
  	
}
  	
  	public Cursor fetchWinner(String inputText) throws SQLException {
  	  //Log.w(TAG, inputText);
  	  SQLiteDatabase db = this.getWritableDatabase();
  	  Cursor mCursor = null;
  	  if (inputText == null  ||  inputText.length () == 0)  {
  	   mCursor = db.query(TBL, new String[] {"rowid _id", W_ID,
  			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
  	     null, null, null, null, null);

  	  }
  	  else {
  	   mCursor = db.query(true, TBL, new String[] {"rowid _id", W_ID,
    			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
  	     W_WINNER + " like '%" + inputText + "%'", null,
  	     null, null, null, null);
  	  }
  	  if (mCursor != null) {
  	   mCursor.moveToFirst();
  	  }
  	  return mCursor;

  	 }
  	
  	public Cursor fetchYear(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", W_ID,
      			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", W_ID,
      			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
    	     W_YEAR + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
  	
  	
  	
  	public Cursor fetchCity(String inputText) throws SQLException {
    	  //Log.w(TAG, inputText);
    	  SQLiteDatabase db = this.getWritableDatabase();
    	  Cursor mCursor = null;
    	  if (inputText == null  ||  inputText.length () == 0)  {
    	   mCursor = db.query(TBL, new String[] {"rowid _id", W_ID,
      			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
    	     null, null, null, null, null);

    	  }
    	  else {
    	   mCursor = db.query(true, TBL, new String[] {"rowid _id", W_ID,
      			 W_COMPETITION, W_WINNER, W_CITY,W_RANK,W_PRIZE,W_COORDINATOR,W_POSITION,W_YEAR}, 
    	     W_CITY + " like '%" + inputText + "%'", null,
    	     null, null, null, null);
    	  }
    	  if (mCursor != null) {
    	   mCursor.moveToFirst();
    	  }
    	  return mCursor;

    	 }
}

